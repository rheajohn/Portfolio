<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
    <?php echo '<p>Hello World! Here are all of my Links [Rhea John & Period 6]</p>'; ?> 
    <ul>
      <li><a href="index.html">index.html</a></li></br>
      <!-- Please make sure to change all the #'s to the proper link names-->
      <li><a href="John_AboutMe.html">John_AboutMe.html</a></li></br>
      <li><a href="John_Resume.html">John_Resume.html</a></li></br>
      <li><a href="John_Projects.html">John_Projects.html</a></li></br>
      <li><a href="John_ContactMe.html">John_ContactMe.html</a></li></br>
      
    <ul>
  </body>
</html>